#include <iostream>
#include <string>
using namespace std;

// 🔹 Class to represent a Book
class Book {
public:
    int id;             // Book ID
    string name;        // Book name
    string author;      // Author name
    bool issued = false; // Book status (false = available)

    // 🔹 Function to add book details
    void add() {
        cout << "Enter Book ID: ";
        cin >> id;
        cin.ignore(); // Clear input buffer

        cout << "Enter Book Name: ";
        getline(cin, name);

        cout << "Enter Author: ";
        getline(cin, author);

        issued = false; // New book is available
        cout << "Book added successfully!\n";
    }

    // 🔹 Function to display book details
    void show() {
        cout << "\nID: " << id
             << "\nName: " << name
             << "\nAuthor: " << author
             << "\nStatus: " << (issued ? "Issued" : "Available") << endl;
    }
};

int main() {
    Book b[100];  // Array to store up to 100 books
    int n = 0;    // Number of books currently stored
    int choice, id;
    bool found;   // Flag to check if book exists

    do {
        // 🔹 Display menu options
        cout << "\n\n--- Library Menu ---\n";
        cout << "1. Add Book\n2. Display Books\n3. Search Book\n4. Issue Book\n5. Return Book\n6. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch(choice) {

            // 🔹 Add a new book
            case 1:
                b[n].add(); // Call add function
                n++;        // Increase book count
                break;

            // 🔹 Display all books
            case 2:
                if(n == 0)
                    cout << "No books available.\n";
                else {
                    for(int i = 0; i < n; i++)
                        b[i].show(); // Display each book
                }
                break;

            // 🔹 Search for a book by ID
            case 3:
                cout << "Enter Book ID: ";
                cin >> id;
                found = false;

                for(int i = 0; i < n; i++) {
                    if(b[i].id == id) {
                        b[i].show(); // Show book details
                        found = true;
                        break;
                    }
                }

                if(!found)
                    cout << "Book not found.\n";
                break;

            // 🔹 Issue a book
            case 4:
                cout << "Enter Book ID to issue: ";
                cin >> id;
                found = false;

                for(int i = 0; i < n; i++) {
                    if(b[i].id == id) {
                        if(!b[i].issued) {
                            b[i].issued = true; // Mark as issued
                            cout << "Book issued successfully.\n";
                        } else {
                            cout << "Book already issued.\n";
                        }
                        found = true;
                        break;
                    }
                }

                if(!found)
                    cout << "Book not found.\n";
                break;

            // 🔹 Return a book
            case 5:
                cout << "Enter Book ID to return: ";
                cin >> id;
                found = false;

                for(int i = 0; i < n; i++) {1
                    if(b[i].id == id) {
                        if(b[i].issued) {
                            b[i].issued = false; // Mark as available
                            cout << "Book returned successfully.\n";
                        } else {
                            cout << "Book was not issued.\n";
                        }
                        found = true;
                        break;
                    }
                }

                if(!found)
                    cout << "Book not found.\n";
                break;

            // 🔹 Exit program
            case 6:
                cout << "Exiting...\n";
                break;

            // 🔹 Invalid input handling
            default:
                cout << "Invalid choice!\n";
        }

    } while(choice != 6); // Loop until user exits

    return 0; // End of program
}